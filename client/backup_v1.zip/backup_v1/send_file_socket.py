import socket
import sys
import os

def send_file(host, port, filename):
    with socket.create_connection((host, port), timeout=10) as sock:
        # Send unlock signal byte 0x01
        sock.sendall(b'\x01')

        # Send file in chunks
        with open(filename, 'rb') as f:
            while True:
                chunk = f.read(4096)
                if not chunk:
                    break
                sock.sendall(chunk)
        # Close socket (server will detect EOF)
    print('File sent.')

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print('Usage: python send_file_socket.py <host> <port> <file>')
        sys.exit(1)
    host = sys.argv[1]
    port = int(sys.argv[2])
    filename = sys.argv[3]
    if not os.path.isfile(filename):
        print('File not found:', filename); sys.exit(1)
    send_file(host, port, filename)