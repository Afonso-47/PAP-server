import os
import sys

from send_file_socket import send_file

if __name__ == "__main__":

    hostname = "10.0.0.1"
    port = 9000

    file_to_send = "./testfile.txt"

    if not os.path.isfile(file_to_send):
        print('File not found:', file_to_send); sys.exit(1)

    try:
        send_file(hostname, port, file_to_send)
        print("File transfer completed successfully.")

    except Exception as e:
        print("An error occurred:", e)
        sys.exit(1)
    
    finally:
        print("Transfer process finished.")
    