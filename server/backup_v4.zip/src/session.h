#ifndef SESSION_H
#define SESSION_H

int handle_unlocked_session(int client_fd);

#endif
